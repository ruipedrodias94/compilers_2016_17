  #include "semantics.h"
#include "sym_tab.h"
#include "estruturas.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void check_ast_to_table(Node *root){

  node_ nn = cria_lista_nodes();
  tab_ tabela = cria_lista_tab();
  Node *program;
  program = root;



    if(program->node_type == type_Program)
    {
      //Program

      //criacao do header
      Node *program_son = program->son;
      insere_lista_tab(tabela, program_son->token, "Class", "", nn);


      while(program_son != NULL)
      {
        //caso existam nos fieldDecl (variaveis globais)
        if(program_son->node_type == type_FieldDecl)
        {

          Node *fieldDecl_son = program_son->son;
          insere_lista_nodes(nn, fieldDecl_son->brother->token, getNode_type(fieldDecl_son->node_type));

        }
         else if(program_son->node_type == type_MethodDecl){
          //method decl header
          Node *methodDecl_son = program_son->son;
          Node *methodHeader_son = methodDecl_son->son;
          node_ nn2 = cria_lista_nodes();
          //return
          insere_lista_nodes(nn2, methodHeader_son->brother->token, "return");


          insere_lista_nodes(nn2, methodHeader_son->brother->token, getNode_type(methodHeader_son->node_type));

          /*Criação das novas tabelas*/

          insere_lista_tab(tabela, methodHeader_son->brother->token, "Method", "", nn2);


        }
        program_son = program_son->brother;
      }
    }



  printf("TABELA\n");
  imprime_lista(tabela);
  printf("FIM TABELA\n");
  return;
}
