#include "estruturas.h"
#include "sym_tab.h"

void check_ast_to_table(Node *root);
